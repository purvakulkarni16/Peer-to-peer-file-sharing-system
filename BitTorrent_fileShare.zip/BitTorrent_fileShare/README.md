# BitTorrent_fileShare
Code for the 2019 Computer Networks (CNT5106C) project at University of Florida.

In this project we are asked to write a P2P file sharing software similar to BitTorrent.
 
Project Team Memebers:
Anagha Joshi-        UFID: 45154948
Nishtha Shrivastav-  UFID: 25945398
Purva Kulkarni-      UFID: 82721493
